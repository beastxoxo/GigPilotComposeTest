package com.gigpilot.splash

import android.graphics.Canvas as NativeCanvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import android.view.View
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        setContent { GigPilotSplash() }
    }
}

@androidx.compose.runtime.Composable
private fun GigPilotSplash() {
    var replay by remember { mutableIntStateOf(0) }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(replay) {
        progress.snapTo(0f)
        progress.animateTo(3.6f, tween(3600, easing = androidx.compose.animation.core.LinearEasing))
    }
    Box(Modifier.fillMaxSize().background(Color.Black).clickable { replay++ }) {
        Canvas(Modifier.fillMaxSize()) {
            val scale = min(size.width / 1920f, size.height / 1080f)
            val ox = (size.width - 1920f * scale) / 2f
            val oy = (size.height - 1080f * scale) / 2f
            drawIntoCanvas { canvas ->
                val c = canvas.nativeCanvas
                val save = c.save()
                c.translate(ox, oy)
                c.scale(scale, scale)
                renderSplash(c, progress.value)
                c.restoreToCount(save)
            }
        }
    }
}

private fun renderSplash(c: NativeCanvas, t: Float) {
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    val white = android.graphics.Color.WHITE
    val silver = android.graphics.Color.rgb(212, 212, 216)
    fun clamp(v: Float) = v.coerceIn(0f, 1f)
    fun seg(v: Float, a: Float, b: Float) = clamp((v - a) / (b - a))
    fun out(v: Float) = 1f - (1f - v) * (1f - v) * (1f - v)
    fun out5(v: Float): Float { val x = 1f - v; return 1f - x*x*x*x*x }
    fun io(v: Float) = if (v < .5f) 4f*v*v*v else 1f - (-2f*v + 2f).let { it*it*it }/2f

    // Soft centered silver halo.
    val glow = clamp(seg(t, .6f, 2f)) * (0.5f + 0.06f * kotlin.math.sin(max(0f, t - 2f) * 2.2f)) * 2f
    p.shader = RadialGradient(960f, 510f, 455f, intArrayOf(0x33D4D4D8, 0x14D4D4D8, 0x00D4D4D8), floatArrayOf(0f, .48f, 1f), Shader.TileMode.CLAMP)
    p.alpha = (255 * glow).toInt().coerceIn(0, 255)
    c.drawCircle(960f, 510f, 455f, p); p.shader = null; p.alpha = 255

    // Ring draws, expands, then fades.
    val ringDraw = io(seg(t, .15f, .95f))
    val ringFade = seg(t, .95f, 1.5f)
    p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.strokeCap = Paint.Cap.ROUND
    p.color = silver; p.alpha = (230f * (1f - out(ringFade))).toInt()
    val radius = 470f + out(ringFade) * 90f
    c.drawArc(RectF(960f-radius, 410f-radius, 960f+radius, 410f+radius), -90f, 360f * ringDraw, false, p)
    p.style = Paint.Style.FILL; p.alpha = 255

    val plate = out5(seg(t, .55f, 1.25f))
    val plateAlpha = (255 * clamp(seg(t, .55f, 1f))).toInt()
    c.save(); c.translate(960f, 410f); c.scale(.82f + .18f * plate, .82f + .18f * plate); c.translate(-960f, -410f)
    p.alpha = plateAlpha
    p.shader = LinearGradient(0f, 250f, 0f, 570f, intArrayOf(0xFF121214.toInt(), android.graphics.Color.BLACK), null, Shader.TileMode.CLAMP)
    c.drawRoundRect(RectF(800f,250f,1120f,570f),72f,72f,p); p.shader = null
    p.style = Paint.Style.STROKE; p.strokeWidth = 2f
    p.shader = LinearGradient(800f,250f,1120f,570f,intArrayOf(0xFF6A6A70.toInt(),0xFF1A1A1D.toInt(),0xFF3A3A3F.toInt()),floatArrayOf(0f,.5f,1f),Shader.TileMode.CLAMP)
    c.drawRoundRect(RectF(801f,251f,1119f,569f),71f,71f,p); p.shader = null; p.style = Paint.Style.FILL
    p.alpha = 255
    c.restore()

    // Grounded shadow under the mark.
    val sh = clamp(seg(t, 1f, 1.7f))
    p.alpha = (255 * sh).toInt()
    p.shader = RadialGradient(960f, 526f, 52f, intArrayOf(0x38D4D4D8,0x00D4D4D8),null,Shader.TileMode.CLAMP)
    c.drawOval(RectF(910f,514f,1010f,529f),p); p.shader = null; p.alpha=255

    val left = out5(seg(t,.8f,1.4f)); val right = out5(seg(t,1f,1.6f))
    val arrowAlphaL = (255*clamp(seg(t,.8f,1.1f))).toInt()
    val arrowAlphaR = (255*clamp(seg(t,1f,1.2f))).toInt()
    val leftPath = Path().apply { moveTo(960f, 311.25f + 46f*(1f-left)); lineTo(883.75f, 503.75f + 46f*(1f-left)); lineTo(960f, 457.5f + 46f*(1f-left)); close() }
    val rightPath = Path().apply { moveTo(960f,311.25f+46f*(1f-right)); lineTo(960f,457.5f+46f*(1f-right)); lineTo(1036.25f,503.75f+46f*(1f-right)); close() }
    p.alpha=arrowAlphaL; p.shader=LinearGradient(883f,504f,960f,311f,intArrayOf(0xFFC9C9CF.toInt(),white),null,Shader.TileMode.CLAMP); c.drawPath(leftPath,p)
    c.save(); c.translate(960f,0f); c.scale(max(right,.0001f),1f); c.translate(-960f,0f)
    p.alpha=arrowAlphaR; p.shader=LinearGradient(1037f,504f,960f,311f,intArrayOf(0xFF76767C.toInt(),0xFFC2C2C8.toInt()),null,Shader.TileMode.CLAMP); c.drawPath(rightPath,p)
    c.restore(); p.shader=null; p.alpha=255
    p.alpha=(255*seg(t,1.35f,1.7f)).toInt(); p.strokeWidth=2.5f; p.color=white; c.drawLine(960f,311.25f,960f,457.5f,p); p.alpha=255

    // Moving silver sheen clipped to the arrow silhouette.
    val sheen = io(seg(t,1.55f,2.3f)); val arrowClip = Path().apply { moveTo(960f,311.25f); lineTo(883.75f,503.75f); lineTo(960f,457.5f); lineTo(1036.25f,503.75f); close() }
    c.save(); c.clipPath(arrowClip)
    val x = -500f + sheen * 1800f
    p.shader = LinearGradient(x,300f,x+360f,300f,intArrayOf(0x00FFFFFF,0xD9FFFFFF.toInt(),0x00FFFFFF),null,Shader.TileMode.CLAMP)
    c.save(); c.skew(-.32f,0f); c.drawRect(x,280f,x+360f,540f,p); c.restore(); c.restore(); p.shader=null

    // Wordmark; split whites match the original art direction.
    val letterStarts = floatArrayOf(1.75f,1.81f,1.87f,1.93f,1.99f,2.05f,2.11f,2.17f)
    val letters = "GigPilot"
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface=Typeface.create("sans-serif-medium",Typeface.NORMAL); textSize=96f; textAlign=Paint.Align.LEFT }
    val widths = letters.map { paint.measureText(it.toString()) }
    val total = widths.sum() - 8f * 2.4f
    var xText = (1920f-total)/2f
    letters.forEachIndexed { i, ch ->
        val a = out(seg(t,letterStarts[i],2.3f+i*.06f))
        paint.color = if (i < 3) white else 0xFFC9C9CF.toInt()
        paint.alpha = (255*a).toInt()
        c.drawText(ch.toString(), xText, 722f + 30f*(1f-a), paint)
        xText += widths[i] - 2.4f
    }
    // Thin silver line expands after the wordmark.
    val line = out(seg(t,2.4f,3f)); p.alpha=(179f*line).toInt(); p.shader=LinearGradient(820f,0f,1100f,0f,intArrayOf(0x00D4D4D8,silver,0x00D4D4D8),null,Shader.TileMode.CLAMP)
    c.drawRect(960f-140f*line,789f,960f+140f*line,791f,p); p.shader=null; p.alpha=255
}
