# GigPilot native Compose splash

This Android Studio project recreates the supplied `GigPilot-splash-live.html` as a native Jetpack Compose screen. The icon plate, silver navigation mark, halo, ring draw, wordmark, light sweep, and underline are drawn with Android Canvas and Compose animation. Tap anywhere to replay the 3.6-second animation.

## Open and build

1. Extract the ZIP and open the `GigPilotCompose` folder in Android Studio.
2. Let Gradle sync (Android Gradle Plugin 8.7.3, Kotlin 2.0.21; Android SDK 35 required).
3. Run the `app` configuration on an Android device or emulator (Android 7.0 / API 24+).

The provided source describes the splash/brand animation only. It does not include other app screens or app behavior. The native drawing follows the original 1920×1080 composition and scales to the available screen while keeping the composition centered.
